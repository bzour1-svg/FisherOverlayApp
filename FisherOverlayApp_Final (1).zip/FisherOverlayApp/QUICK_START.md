# ⚡ البدء السريع - Fisher Likee Overlay

## 5 دقائق فقط للبدء!

### الخطوة 1: التحضيرات (1 دقيقة)

```bash
# تحميل المشروع
unzip FisherOverlayApp_Complete.zip
cd FisherOverlayApp
```

### الخطوة 2: البناء (3 دقائق)

#### الخيار A: استخدام Android Studio (الأسهل)
1. افتح Android Studio
2. File → Open → اختر مجلد FisherOverlayApp
3. انتظر مزامنة Gradle
4. Build → Build APK(s)

#### الخيار B: سطر الأوامر
```bash
./gradlew assembleDebug
```

### الخطوة 3: التثبيت (1 دقيقة)

```bash
adb install app/build/outputs/apk/debug/app-debug.apk
```

---

## الاستخدام الفوري

### 1. افتح اللعبة
```
تطبيق Fisher Likee → ابدأ اللعب
```

### 2. افتح التطبيق
```
Fisher Overlay → اضغط "Start Overlay"
```

### 3. منح الأذونات
```
Allow → اختر الشاشة → Done
```

### 4. شاهد المؤشرات!
```
🟡 دائرة ذهبية = أفضل هدف
🟢 دائرة خضراء = هدف جيد
🔵 دائرة زرقاء = هدف عادي
```

---

## المشاكل الشائعة

### ❌ "SDK not found"
```bash
# تأكد من local.properties
cat local.properties
# يجب أن يحتوي على: sdk.dir=/path/to/android-sdk
```

### ❌ "No devices"
```bash
# فعّل USB Debugging على الجهاز
# Settings → Developer Options → USB Debugging
adb devices
```

### ❌ "Build failed"
```bash
./gradlew clean assembleDebug
```

---

## الملفات المهمة

| الملف | الوصف |
|------|-------|
| `README.md` | شرح شامل |
| `BUILD_GUIDE.md` | تعليمات البناء المفصلة |
| `INSTALLATION.md` | خطوات التثبيت |
| `ARCHITECTURE.md` | البنية المعمارية |

---

## الخطوات التالية

- 📖 اقرأ [README.md](README.md) للمزيد من المعلومات
- 🔧 اقرأ [BUILD_GUIDE.md](BUILD_GUIDE.md) للتفاصيل
- 🏗️ اقرأ [ARCHITECTURE.md](ARCHITECTURE.md) للبنية

---

## نصائح سريعة

✅ **للأداء الأفضل**:
- استخدم جهاز بمعالج Snapdragon 660+
- أغلق التطبيقات الأخرى
- استخدم شاشة بدقة 1080p

✅ **للكشف الأفضل**:
- تأكد من إضاءة جيدة
- ضع الجهاز بزاوية مناسبة
- استخدم شاشة نظيفة

---

**جاهز للبدء؟ ابدأ الآن! 🚀**
