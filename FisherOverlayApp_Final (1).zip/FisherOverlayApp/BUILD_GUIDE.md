# Fisher Likee Overlay - بناء وتثبيت التطبيق

## نظرة عامة

تطبيق **Fisher Overlay** هو تطبيق أندرويد متقدم يعمل كطبقة فوقية (Overlay) على لعبة "Fisher Likee" ويوفر تحليلاً فوري للأسماك مع توصيات تصويب ذكية.

### المميزات الرئيسية

- **التقاط الشاشة في الوقت الفعلي** باستخدام MediaProjection API
- **كشف الأسماك** باستخدام معالجة الألوان والأنماط
- **تحليل القيمة إلى الصعوبة** لتحديد الأهداف المثالية
- **تتبع الحركة** والتنبؤ بمسارات الأسماك
- **مؤشرات بصرية** فوق الأسماك المستهدفة
- **دعم جميع أنواع الأسماك الـ 12** مع قيمها الدقيقة

## متطلبات النظام

### للتطوير:
- **Android Studio 2023.1+** أو أي محرر نصوص مع Android SDK
- **Android SDK API Level 34** (Target SDK)
- **Gradle 8.1+**
- **Java 11+**
- **Android Build Tools 34.0.0+**

### للتثبيت على الجهاز:
- **Android 6.0 (API 24)** أو أحدث
- **صلاحيات SYSTEM_ALERT_WINDOW**
- **صلاحيات MediaProjection**

## خطوات البناء

### 1. إعداد بيئة التطوير

```bash
# تثبيت Android SDK (إذا لم يكن مثبتاً)
# على Ubuntu/Debian:
sudo apt-get install android-sdk android-sdk-build-tools

# على macOS:
brew install android-sdk

# على Windows:
# قم بتحميل Android Studio من https://developer.android.com/studio
```

### 2. استنساخ المشروع أو نسخه

```bash
cd /path/to/FisherOverlayApp
```

### 3. تكوين SDK

تأكد من أن `local.properties` يحتوي على المسار الصحيح لـ Android SDK:

```properties
sdk.dir=/path/to/android-sdk
```

### 4. بناء ملف APK

#### الطريقة 1: استخدام Gradle من سطر الأوامر

```bash
# بناء APK Debug
./gradlew assembleDebug

# بناء APK Release (يتطلب توقيع)
./gradlew assembleRelease

# بناء مع تنظيف أولاً
./gradlew clean assembleDebug
```

#### الطريقة 2: استخدام Android Studio

1. افتح Android Studio
2. اختر `File > Open` واختر مجلد المشروع
3. انتظر حتى ينتهي Gradle من المزامنة
4. اختر `Build > Build Bundle(s) / APK(s) > Build APK(s)`
5. سيظهر ملف APK في `app/build/outputs/apk/debug/`

### 5. تثبيت APK على الجهاز

```bash
# تثبيت APK Debug
adb install app/build/outputs/apk/debug/app-debug.apk

# أو إذا كان التطبيق مثبتاً بالفعل
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

## هيكل المشروع

```
FisherOverlayApp/
├── app/
│   ├── src/
│   │   └── main/
│   │       ├── java/com/fisher/overlay/
│   │       │   ├── MainActivity.java              # النشاط الرئيسي
│   │       │   ├── OverlayService.java            # خدمة الطبقة الفوقية
│   │       │   ├── ScreenCaptureService.java      # خدمة التقاط الشاشة
│   │       │   ├── FishDetector.java              # محرك كشف الأسماك
│   │       │   ├── FishAnalysisEngine.java        # محرك تحليل الأسماك
│   │       │   ├── FishDatabase.java              # قاعدة بيانات الأسماك
│   │       │   ├── FishData.java                  # فئة بيانات السمكة
│   │       │   ├── OverlayView.java               # عرض الطبقة الفوقية
│   │       │   ├── NotificationManager.java       # مدير الإشعارات
│   │       │   └── FisherOverlayApplication.java  # فئة التطبيق
│   │       ├── res/
│   │       │   ├── layout/
│   │       │   │   └── activity_main.xml
│   │       │   ├── values/
│   │       │   │   ├── strings.xml
│   │       │   │   ├── colors.xml
│   │       │   │   ├── dimens.xml
│   │       │   │   └── styles.xml
│   │       │   ├── drawable/
│   │       │   └── mipmap/
│   │       └── AndroidManifest.xml
│   ├── build.gradle
│   └── proguard-rules.pro
├── build.gradle
├── settings.gradle
├── gradle.properties
├── local.properties
└── gradlew
```

## قاعدة بيانات الأسماك

التطبيق يدعم جميع أنواع الأسماك الـ 12 من لعبة Fisher Likee:

### أسماك ذات قيمة منخفضة (3-5 ماس):
1. **قنديل البحر** (Jellyfish) - 3 ماس
2. **سلحفاة البحر** (Sea Turtle) - 3 ماس
3. **السمكة الحمراء** (Red Fish) - 4 ماس
4. **الدولفين الذهبي** (Golden Dolphin) - 4 ماس
5. **السمكة الشريرة** (Evil Fish) - 5 ماس

### أسماك ذات قيمة متوسطة (5-12 ماس):
6. **سمكة كبيرة شريرة** (Big Evil Fish) - 5 ماس
7. **قنديل البحر الذهبي** (Golden Jellyfish) - 8 ماس
8. **السلحفاة الذهبية** (Golden Turtle) - 10 ماس
9. **سمك القرش الذهبي** (Golden Shark) - 12 ماس
10. **تمساح** (Crocodile) - 12 ماس

### أسماك ذات قيمة عالية (30-40 ماس):
11. **قرش** (Shark) - 30 ماس
12. **ملك التنين** (Dragon King) - 40 ماس

## استخدام التطبيق

### الخطوة 1: منح الأذونات

عند تشغيل التطبيق لأول مرة، سيطلب الأذونات التالية:
- **SYSTEM_ALERT_WINDOW**: للرسم فوق التطبيقات الأخرى
- **MediaProjection**: لالتقاط شاشة الجهاز

### الخطوة 2: بدء الطبقة الفوقية

1. افتح تطبيق Fisher Likee
2. افتح تطبيق Fisher Overlay
3. اضغط على زر "Start Overlay"
4. اختر شاشة الجهاز عند الطلب
5. سيبدأ التطبيق في تحليل الأسماك

### الخطوة 3: قراءة المؤشرات

- **دائرة ذهبية مع صليب**: السمكة الأفضل للتصويب (أعلى نسبة قيمة/صعوبة)
- **دائرة خضراء**: أسماك جيدة بنسبة قيمة عالية
- **دائرة زرقاء**: أسماك عادية
- **خط برتقالي**: اتجاه حركة السمكة المتنبأ به

## الميزات المتقدمة

### تحليل القيمة إلى الصعوبة

يحسب التطبيق نسبة `Value-to-Difficulty` لكل سمكة:
- **القيمة**: عدد الماسات التي تحصل عليها من السمكة
- **الصعوبة**: تقدير مدى صعوبة اصطياد السمكة بناءً على حجمها وحركتها

**الصيغة**: `Ratio = Value / Difficulty`

أعلى نسبة = أفضل هدف

### تتبع الحركة والتنبؤ

يتتبع التطبيق حركة كل سمكة عبر عدة إطارات ويحسب:
- **السرعة**: كم بكسل تتحرك السمكة في الثانية
- **الاتجاه**: اتجاه حركة السمكة
- **الاستقرار**: مدى قابلية التنبؤ بحركة السمكة

### معالجة الألوان

يستخدم التطبيق كشف الألوان لتحديد نوع السمكة:
- **الأسماك الذهبية**: نطاق لون أصفر/ذهبي
- **الأسماك الحمراء**: نطاق لون أحمر/وردي
- **الأسماك الزرقاء**: نطاق لون أزرق
- **الأسماك الخضراء**: نطاق لون أخضر
- **الأسماك الأرجوانية**: نطاق لون بنفسجي/وردي

## استكشاف الأخطاء والمشاكل

### المشكلة: لا يتم التقاط الشاشة

**الحل**:
- تأكد من منح صلاحية MediaProjection
- تأكد من أن اللعبة تعمل بالفعل
- أعد تشغيل التطبيق

### المشكلة: الأسماك لا تُكتشف

**الحل**:
- تأكد من أن الإضاءة كافية
- قد تحتاج إلى ضبط نطاقات الألوان في `FishDetector.java`
- تحقق من أن اللعبة في المقدمة

### المشكلة: الأداء بطيء

**الحل**:
- قلل معدل الإطارات في `ScreenCaptureService.java` (FRAME_RATE)
- أغلق التطبيقات الأخرى
- استخدم جهازاً بمعالج أقوى

## التطوير والتخصيص

### إضافة أسماك جديدة

عدّل `FishDatabase.java`:

```java
private void initializeFishDatabase() {
    // أضف سمكة جديدة
    addFish(13, "اسم عربي", "English Name", 50, "high", "color");
}
```

### تعديل حساسية الكشف

عدّل `FishDetector.java`:

```java
private static final float CONFIDENCE_THRESHOLD = 0.5f; // غيّر هذا
private static final int MIN_FISH_SIZE = 20; // أو هذا
```

### تخصيص الألوان

عدّل `OverlayView.java`:

```java
paintBestTarget.setColor(Color.parseColor("#FFD700")); // غيّر اللون
```

## الأداء والتحسينات

- **معدل الإطارات**: 15 FPS (قابل للتعديل)
- **حجم الإطار**: دقة الشاشة الكاملة
- **استهلاك الذاكرة**: ~50-100 MB
- **استهلاك البطارية**: معتدل (خدمة Foreground)

## الترخيص والاستخدام

هذا التطبيق مخصص للاستخدام التعليمي والشخصي فقط. استخدام هذا التطبيق مع الألعاب قد ينتهك شروط الخدمة.

## الدعم والمساعدة

للمساعدة في البناء أو الاستخدام:
1. تحقق من هذا الدليل
2. راجع التعليقات في الكود
3. تحقق من السجلات في Logcat

## الملفات المهمة

- `MainActivity.java`: نقطة الدخول الرئيسية
- `FishDetector.java`: محرك الكشف الأساسي
- `FishAnalysisEngine.java`: محرك التحليل المتقدم
- `OverlayView.java`: رسم المؤشرات
- `FishDatabase.java`: قاعدة بيانات الأسماك

## الإصدار

- **الإصدار**: 1.0
- **تاريخ الإنشاء**: مايو 2026
- **الحالة**: جاهز للاستخدام
