package com.fisher.overlay;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Database of all fish types in Fisher Likee game.
 * Manages fish information, difficulty factors, and lookup methods.
 */
public class FishDatabase {
    private static final FishDatabase instance = new FishDatabase();
    private Map<Integer, FishData> fishMap;
    private Map<String, Float> difficultyFactors;
    private Map<Integer, FishMovementProfile> movementProfiles;
    
    private FishDatabase() {
        initializeFishDatabase();
        initializeDifficultyFactors();
        initializeMovementProfiles();
    }
    
    public static FishDatabase getInstance() {
        return instance;
    }
    
    /**
     * Initialize all fish data from the game.
     */
    private void initializeFishDatabase() {
        fishMap = new HashMap<>();
        
        // Small value fish (3-5 diamonds)
        addFish(1, "قنديل البحر", "Jellyfish", 3, "small", "purple");
        addFish(2, "سلحفاة البحر", "Sea Turtle", 3, "small", "green");
        addFish(3, "السمكة الحمراء", "Red Fish", 4, "small", "red");
        addFish(4, "الدولفين الذهبي", "Golden Dolphin", 4, "small", "purple");
        addFish(5, "السمكة الشريرة", "Evil Fish", 5, "small", "blue");
        
        // Medium value fish (5-12 diamonds)
        addFish(6, "سمكة كبيرة شريرة", "Big Evil Fish", 5, "medium", "colorful");
        addFish(7, "قنديل البحر الذهبي", "Golden Jellyfish", 8, "medium", "golden");
        addFish(8, "السلحفاة الذهبية", "Golden Turtle", 10, "medium", "golden");
        addFish(9, "سمك القرش الذهبي", "Golden Shark", 12, "medium", "golden");
        addFish(10, "تمساح", "Crocodile", 12, "medium", "green");
        
        // High value fish (30-40 diamonds)
        addFish(11, "قرش", "Shark", 30, "high", "golden");
        addFish(12, "ملك التنين", "Dragon King", 40, "high", "red");
    }
    
    /**
     * Add a fish to the database.
     */
    private void addFish(int id, String nameAr, String nameEn, int value, 
                        String category, String colorPrimary) {
        FishData fish = new FishData();
        fish.id = id;
        fish.nameAr = nameAr;
        fish.nameEn = nameEn;
        fish.value = value;
        fish.category = category;
        fish.colorPrimary = colorPrimary;
        fish.difficulty = difficultyFactors.getOrDefault(category, 1.0f);
        fish.calculateRatio();
        fishMap.put(id, fish);
    }
    
    /**
     * Initialize difficulty factors for each category.
     */
    private void initializeDifficultyFactors() {
        difficultyFactors = new HashMap<>();
        difficultyFactors.put("small", 1.0f);    // Easy to catch
        difficultyFactors.put("medium", 1.5f);   // Medium difficulty
        difficultyFactors.put("high", 2.5f);     // Hard to catch
    }
    
    /**
     * Initialize movement profiles for each fish type.
     * Based on actual gameplay analysis.
     */
    private void initializeMovementProfiles() {
        movementProfiles = new HashMap<>();
        
        // Small yellow fish: very fast, linear paths, spawn in formations
        FishMovementProfile smallYellow = new FishMovementProfile();
        smallYellow.avgSpeed = 300.0f;  // pixels per second
        smallYellow.speedVariance = 50.0f;
        smallYellow.pathType = "linear";
        smallYellow.spawnFrequency = "very_high";
        smallYellow.formationSpawning = true;
        smallYellow.rarity = 1; // most common
        movementProfiles.put(1, smallYellow); // Jellyfish
        
        // Small red fish: fast, linear, common
        FishMovementProfile smallRed = new FishMovementProfile();
        smallRed.avgSpeed = 250.0f;
        smallRed.speedVariance = 40.0f;
        smallRed.pathType = "linear";
        smallRed.spawnFrequency = "high";
        smallRed.formationSpawning = true;
        smallRed.rarity = 2; // second most common
        movementProfiles.put(3, smallRed); // Red Fish
        
        // Medium fish: moderate speed, linear, occasional pairs
        FishMovementProfile mediumFish = new FishMovementProfile();
        mediumFish.avgSpeed = 150.0f;
        mediumFish.speedVariance = 30.0f;
        mediumFish.pathType = "linear";
        mediumFish.spawnFrequency = "medium";
        mediumFish.formationSpawning = false;
        mediumFish.rarity = 3; // regular
        movementProfiles.put(2, mediumFish);  // Sea Turtle
        movementProfiles.put(4, mediumFish);  // Golden Dolphin
        movementProfiles.put(7, mediumFish);  // Golden Jellyfish
        movementProfiles.put(8, mediumFish);  // Golden Turtle
        movementProfiles.put(10, mediumFish); // Crocodile
        
        // Large fish: slow, linear, solitary
        FishMovementProfile largeFish = new FishMovementProfile();
        largeFish.avgSpeed = 100.0f;
        largeFish.speedVariance = 20.0f;
        largeFish.pathType = "linear";
        largeFish.spawnFrequency = "low";
        largeFish.formationSpawning = false;
        largeFish.rarity = 4; // uncommon
        movementProfiles.put(9, largeFish);  // Golden Shark
        movementProfiles.put(11, largeFish); // Shark
        
        // Boss Dragon: very slow, complex snaking path
        FishMovementProfile dragonBoss = new FishMovementProfile();
        dragonBoss.avgSpeed = 80.0f;
        dragonBoss.speedVariance = 15.0f;
        dragonBoss.pathType = "snaking";
        dragonBoss.spawnFrequency = "very_low";
        dragonBoss.formationSpawning = false;
        dragonBoss.rarity = 5; // rare
        dragonBoss.isBoss = true;
        movementProfiles.put(12, dragonBoss); // Dragon King
        
        // Evil Fish: medium-fast, linear
        FishMovementProfile evilFish = new FishMovementProfile();
        evilFish.avgSpeed = 200.0f;
        evilFish.speedVariance = 35.0f;
        evilFish.pathType = "linear";
        evilFish.spawnFrequency = "medium";
        evilFish.formationSpawning = false;
        evilFish.rarity = 3;
        movementProfiles.put(5, evilFish);  // Evil Fish
        movementProfiles.put(6, evilFish);  // Big Evil Fish
    }
    
    /**
     * Get fish by ID.
     */
    public FishData getFishById(int id) {
        return fishMap.get(id);
    }
    
    /**
     * Get all fish.
     */
    public List<FishData> getAllFish() {
        return new ArrayList<>(fishMap.values());
    }
    
    /**
     * Get fish by category.
     */
    public List<FishData> getFishByCategory(String category) {
        List<FishData> result = new ArrayList<>();
        for (FishData fish : fishMap.values()) {
            if (fish.category.equals(category)) {
                result.add(fish);
            }
        }
        return result;
    }
    
    /**
     * Get fish by color.
     */
    public List<FishData> getFishByColor(String color) {
        List<FishData> result = new ArrayList<>();
        for (FishData fish : fishMap.values()) {
            if (fish.colorPrimary.equalsIgnoreCase(color)) {
                result.add(fish);
            }
        }
        return result;
    }
    
    /**
     * Get difficulty factor for a category.
     */
    public float getDifficultyFactor(String category) {
        return difficultyFactors.getOrDefault(category, 1.0f);
    }
    
    /**
     * Get total number of fish types.
     */
    public int getTotalFishTypes() {
        return fishMap.size();
    }
    
    /**
     * Get movement profile for a fish type.
     */
    public FishMovementProfile getMovementProfile(int fishId) {
        return movementProfiles.getOrDefault(fishId, new FishMovementProfile());
    }
    
    /**
     * Inner class for fish movement characteristics.
     */
    public static class FishMovementProfile {
        public float avgSpeed;              // pixels per second
        public float speedVariance;         // variation in speed
        public String pathType;             // "linear", "snaking", "circular"
        public String spawnFrequency;       // "very_high", "high", "medium", "low", "very_low"
        public boolean formationSpawning;   // spawns in groups
        public int rarity;                  // 1=most common, 5=rarest
        public boolean isBoss;              // is this a boss fish
        
        public FishMovementProfile() {
            this.avgSpeed = 150.0f;
            this.speedVariance = 30.0f;
            this.pathType = "linear";
            this.spawnFrequency = "medium";
            this.formationSpawning = false;
            this.rarity = 3;
            this.isBoss = false;
        }
    }
}
