package com.fisher.overlay;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Advanced fish analysis engine with gameplay-aware targeting strategies.
 * Incorporates movement patterns, spawn behavior, and value-to-difficulty ratios.
 * Based on actual Fisher Likee gameplay analysis.
 */
public class FishAnalysisEngine {
    private static final String TAG = "FishAnalysisEngine";
    private FishDatabase fishDatabase;
    private Map<Integer, FishTrackingData> trackingHistory;
    private static final int HISTORY_SIZE = 30; // Keep last 30 frames for velocity calculation
    private static final float SCREEN_WIDTH = 1080.0f;
    private static final float SCREEN_HEIGHT = 1920.0f;
    
    /**
     * Inner class for tracking fish movement history.
     */
    private static class FishTrackingData {
        int fishId;
        List<FishPositionSnapshot> positions;
        long lastUpdateTime;
        float avgSpeed;
        int consecutiveFrames;
        
        FishTrackingData(int fishId) {
            this.fishId = fishId;
            this.positions = new ArrayList<>();
            this.lastUpdateTime = System.currentTimeMillis();
            this.avgSpeed = 0.0f;
            this.consecutiveFrames = 0;
        }
    }
    
    /**
     * Inner class for position snapshots.
     */
    private static class FishPositionSnapshot {
        float x, y;
        long timestamp;
        
        FishPositionSnapshot(float x, float y, long timestamp) {
            this.x = x;
            this.y = y;
            this.timestamp = timestamp;
        }
    }
    
    public FishAnalysisEngine() {
        this.fishDatabase = FishDatabase.getInstance();
        this.trackingHistory = new HashMap<>();
    }
    
    /**
     * Analyze detected fish and return ranked targets with gameplay-aware strategy.
     */
    public AnalysisResult analyzeFish(List<FishData> detectedFish) {
        AnalysisResult result = new AnalysisResult();
        
        if (detectedFish == null || detectedFish.isEmpty()) {
            return result;
        }
        
        // Update tracking history and calculate velocities
        updateTrackingHistory(detectedFish);
        
        // Calculate advanced metrics for each fish
        for (FishData fish : detectedFish) {
            calculateAdvancedMetrics(fish);
        }
        
        // Rank fish by various criteria
        result.bestByRatio = rankByValueRatio(detectedFish);
        result.bestByValue = rankByValue(detectedFish);
        result.bestByEase = rankByEase(detectedFish);
        result.bestBySpeed = rankBySpeed(detectedFish);
        result.bestByRarity = rankByRarity(detectedFish);
        result.bestOverall = selectBestOverall(detectedFish);
        result.allFish = new ArrayList<>(detectedFish);
        
        return result;
    }
    
    /**
     * Update tracking history for movement prediction and velocity calculation.
     */
    private void updateTrackingHistory(List<FishData> detectedFish) {
        for (FishData fish : detectedFish) {
            FishTrackingData tracking = trackingHistory.get(fish.id);
            if (tracking == null) {
                tracking = new FishTrackingData(fish.id);
                trackingHistory.put(fish.id, tracking);
            }
            
            // Add current position
            tracking.positions.add(new FishPositionSnapshot(
                fish.getCenterX(), fish.getCenterY(), System.currentTimeMillis()));
            
            // Keep only recent history
            if (tracking.positions.size() > HISTORY_SIZE) {
                tracking.positions.remove(0);
            }
            
            tracking.lastUpdateTime = System.currentTimeMillis();
            tracking.consecutiveFrames++;
        }
    }
    
    /**
     * Calculate advanced metrics for a fish including velocity and trajectory.
     */
    private void calculateAdvancedMetrics(FishData fish) {
        FishTrackingData tracking = trackingHistory.get(fish.id);
        
        if (tracking != null && tracking.positions.size() >= 2) {
            // Calculate velocity from history
            FishPositionSnapshot latest = tracking.positions.get(tracking.positions.size() - 1);
            FishPositionSnapshot previous = tracking.positions.get(tracking.positions.size() - 2);
            
            long timeDiff = latest.timestamp - previous.timestamp;
            if (timeDiff > 0) {
                fish.velocityX = (latest.x - previous.x) / (timeDiff / 1000.0f);
                fish.velocityY = (latest.y - previous.y) / (timeDiff / 1000.0f);
                
                // Calculate actual speed
                float dx = latest.x - previous.x;
                float dy = latest.y - previous.y;
                float distance = (float) Math.sqrt(dx * dx + dy * dy);
                float speed = distance / (timeDiff / 1000.0f);
                
                // Update average speed
                tracking.avgSpeed = (tracking.avgSpeed * 0.7f) + (speed * 0.3f);
                fish.actualSpeed = tracking.avgSpeed;
            }
            
            // Calculate trajectory stability (how predictable the fish is)
            float trajectoryStability = calculateTrajectoryStability(tracking);
            fish.trajectoryStability = trajectoryStability;
            
            // Get movement profile from database
            FishDatabase.FishMovementProfile profile = fishDatabase.getMovementProfile(fish.id);
            
            // Adjust difficulty based on actual movement vs expected
            float speedRatio = fish.actualSpeed / profile.avgSpeed;
            if (speedRatio > 1.2f) {
                // Fish is faster than expected = harder to catch
                fish.difficulty *= 1.15f;
            } else if (speedRatio < 0.8f) {
                // Fish is slower than expected = easier to catch
                fish.difficulty *= 0.9f;
            }
            
            // Adjust for trajectory stability
            if (trajectoryStability < 0.3f) {
                // Erratic movement = harder to catch
                fish.difficulty *= 1.2f;
            } else if (trajectoryStability > 0.8f) {
                // Predictable movement = easier to catch
                fish.difficulty *= 0.85f;
            }
        }
        
        fish.calculateRatio();
    }
    
    /**
     * Calculate how stable/predictable a fish's trajectory is (0.0 to 1.0).
     */
    private float calculateTrajectoryStability(FishTrackingData tracking) {
        if (tracking.positions.size() < 3) {
            return 0.5f;
        }
        
        float totalDeviation = 0;
        int comparisons = 0;
        
        // Look at last 10 positions for stability
        int startIdx = Math.max(0, tracking.positions.size() - 10);
        for (int i = startIdx + 1; i < tracking.positions.size(); i++) {
            FishPositionSnapshot curr = tracking.positions.get(i);
            FishPositionSnapshot prev = tracking.positions.get(i - 1);
            
            float dx = curr.x - prev.x;
            float dy = curr.y - prev.y;
            float distance = (float) Math.sqrt(dx * dx + dy * dy);
            
            totalDeviation += distance;
            comparisons++;
        }
        
        if (comparisons == 0) return 0.5f;
        
        float avgDeviation = totalDeviation / comparisons;
        // Normalize to 0-1 range (lower deviation = higher stability)
        return Math.min(1.0f, 1.0f / (1.0f + avgDeviation / 50.0f));
    }
    
    /**
     * Rank fish by value-to-difficulty ratio.
     */
    private List<FishData> rankByValueRatio(List<FishData> fish) {
        List<FishData> ranked = new ArrayList<>(fish);
        Collections.sort(ranked, (a, b) -> Float.compare(b.valueRatio, a.valueRatio));
        return ranked;
    }
    
    /**
     * Rank fish by pure value (diamonds).
     */
    private List<FishData> rankByValue(List<FishData> fish) {
        List<FishData> ranked = new ArrayList<>(fish);
        Collections.sort(ranked, (a, b) -> Integer.compare(b.value, a.value));
        return ranked;
    }
    
    /**
     * Rank fish by ease of catching (inverse difficulty).
     */
    private List<FishData> rankByEase(List<FishData> fish) {
        List<FishData> ranked = new ArrayList<>(fish);
        Collections.sort(ranked, (a, b) -> Float.compare(a.difficulty, b.difficulty));
        return ranked;
    }
    
    /**
     * Rank fish by actual speed (fastest = hardest to catch).
     */
    private List<FishData> rankBySpeed(List<FishData> fish) {
        List<FishData> ranked = new ArrayList<>(fish);
        Collections.sort(ranked, (a, b) -> Float.compare(a.actualSpeed, b.actualSpeed));
        return ranked;
    }
    
    /**
     * Rank fish by rarity (rarer = higher priority).
     */
    private List<FishData> rankByRarity(List<FishData> fish) {
        List<FishData> ranked = new ArrayList<>(fish);
        Collections.sort(ranked, (a, b) -> {
            FishDatabase.FishMovementProfile profileA = fishDatabase.getMovementProfile(a.id);
            FishDatabase.FishMovementProfile profileB = fishDatabase.getMovementProfile(b.id);
            return Integer.compare(profileB.rarity, profileA.rarity);
        });
        return ranked;
    }
    
    /**
     * Select the best overall target considering all factors.
     * Uses gameplay-aware strategy: prioritize high-value rare fish,
     * but also consider ease of catching and current availability.
     */
    private FishData selectBestOverall(List<FishData> fish) {
        if (fish.isEmpty()) {
            return null;
        }
        
        FishData best = null;
        float bestScore = -1;
        
        for (FishData f : fish) {
            FishDatabase.FishMovementProfile profile = fishDatabase.getMovementProfile(f.id);
            
            // Composite scoring formula based on gameplay analysis:
            // - Value: 35% (primary goal is earning diamonds)
            // - Ratio: 25% (value per difficulty)
            // - Ease: 15% (1/difficulty - easier = better)
            // - Rarity: 15% (rare fish = higher priority)
            // - Stability: 10% (predictable = easier to hit)
            
            float valueScore = f.value * 0.35f;
            float ratioScore = f.valueRatio * 0.25f;
            float easeScore = (1.0f / f.difficulty) * 0.15f;
            float rarityScore = ((6 - profile.rarity) / 5.0f) * 0.15f; // Invert so rarer = higher
            float stabilityScore = f.trajectoryStability * 0.1f;
            
            float totalScore = valueScore + ratioScore + easeScore + rarityScore + stabilityScore;
            
            // Bonus for boss fish if they're on screen
            if (profile.isBoss) {
                totalScore *= 1.5f; // 50% bonus for bosses
            }
            
            // Penalty for very fast fish (harder to hit)
            if (f.actualSpeed > 250.0f) {
                totalScore *= 0.85f;
            }
            
            if (totalScore > bestScore) {
                bestScore = totalScore;
                best = f;
            }
        }
        
        return best;
    }
    
    /**
     * Predict where a fish will be in the next N milliseconds.
     * Takes into account movement profile and trajectory stability.
     */
    public FishData predictFishPosition(FishData fish, long milliseconds) {
        FishData prediction = new FishData();
        prediction.id = fish.id;
        prediction.nameAr = fish.nameAr;
        prediction.nameEn = fish.nameEn;
        prediction.value = fish.value;
        prediction.category = fish.category;
        prediction.colorPrimary = fish.colorPrimary;
        
        float seconds = milliseconds / 1000.0f;
        
        // Get movement profile for more accurate prediction
        FishDatabase.FishMovementProfile profile = fishDatabase.getMovementProfile(fish.id);
        
        // For snaking/complex paths, use less velocity extrapolation
        float velocityFactor = profile.pathType.equals("snaking") ? 0.5f : 1.0f;
        
        prediction.x = fish.x + (fish.velocityX * seconds * velocityFactor);
        prediction.y = fish.y + (fish.velocityY * seconds * velocityFactor);
        prediction.width = fish.width;
        prediction.height = fish.height;
        
        // Clamp to screen bounds
        prediction.x = Math.max(0, Math.min(SCREEN_WIDTH, prediction.x));
        prediction.y = Math.max(0, Math.min(SCREEN_HEIGHT, prediction.y));
        
        return prediction;
    }
    
    /**
     * Get recommended shooting direction for a fish.
     * Predicts where the fish will be and calculates lead angle.
     */
    public ShootingRecommendation getShootingRecommendation(FishData fish) {
        ShootingRecommendation rec = new ShootingRecommendation();
        rec.fishId = fish.id;
        rec.targetX = fish.getCenterX();
        rec.targetY = fish.getCenterY();
        
        // Predict where to shoot (lead the target)
        // Use 200ms prediction for fast fish, 300ms for slow fish
        long predictionTime = fish.actualSpeed > 200.0f ? 200 : 300;
        FishData predictedPosition = predictFishPosition(fish, predictionTime);
        rec.predictedX = predictedPosition.getCenterX();
        rec.predictedY = predictedPosition.getCenterY();
        
        // Calculate angle and distance
        float dx = rec.predictedX - rec.targetX;
        float dy = rec.predictedY - rec.targetY;
        rec.angle = (float) Math.atan2(dy, dx);
        rec.distance = (float) Math.sqrt(dx * dx + dy * dy);
        
        // Confidence based on trajectory stability and tracking frames
        FishTrackingData tracking = trackingHistory.get(fish.id);
        if (tracking != null) {
            float stabilityConfidence = fish.trajectoryStability;
            float trackingConfidence = Math.min(1.0f, tracking.consecutiveFrames / 10.0f);
            rec.confidence = (stabilityConfidence * 0.6f) + (trackingConfidence * 0.4f);
        } else {
            rec.confidence = 0.3f;
        }
        
        return rec;
    }
    
    /**
     * Detect if a fish is about to leave the screen.
     */
    public boolean isFishLeavingScreen(FishData fish) {
        float margin = 100.0f; // pixels
        return fish.getCenterX() < margin || 
               fish.getCenterX() > SCREEN_WIDTH - margin ||
               fish.getCenterY() < margin ||
               fish.getCenterY() > SCREEN_HEIGHT - margin;
    }
    
    /**
     * Result class for analysis.
     */
    public static class AnalysisResult {
        public List<FishData> bestByRatio;
        public List<FishData> bestByValue;
        public List<FishData> bestByEase;
        public List<FishData> bestBySpeed;
        public List<FishData> bestByRarity;
        public FishData bestOverall;
        public List<FishData> allFish;
        
        public AnalysisResult() {
            this.bestByRatio = new ArrayList<>();
            this.bestByValue = new ArrayList<>();
            this.bestByEase = new ArrayList<>();
            this.bestBySpeed = new ArrayList<>();
            this.bestByRarity = new ArrayList<>();
            this.allFish = new ArrayList<>();
        }
    }
    
    /**
     * Shooting recommendation class.
     */
    public static class ShootingRecommendation {
        public int fishId;
        public float targetX;
        public float targetY;
        public float predictedX;
        public float predictedY;
        public float angle;
        public float distance;
        public float confidence;
    }
}
