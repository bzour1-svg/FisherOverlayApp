package com.fisher.overlay;

import android.app.Service;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.WindowManager;
import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;
import java.nio.ByteBuffer;

/**
 * Service for capturing screen frames using MediaProjection API.
 * Runs in foreground and continuously captures frames for analysis.
 */
public class ScreenCaptureService extends Service {
    private static final String TAG = "ScreenCaptureService";
    private static final int NOTIFICATION_ID = 1001;
    private static final int FRAME_RATE = 15; // FPS
    
    private MediaProjection mediaProjection;
    private ImageReader imageReader;
    private Handler handler;
    private int screenWidth;
    private int screenHeight;
    private int screenDensity;
    private ScreenCaptureCallback callback;
    private boolean isCapturing = false;
    
    /**
     * Callback interface for frame capture.
     */
    public interface ScreenCaptureCallback {
        void onFrameCaptured(Bitmap frame);
        void onCaptureStopped();
    }
    
    @Override
    public void onCreate() {
        super.onCreate();
        handler = new Handler(Looper.getMainLooper());
        getScreenDimensions();
    }
    
    /**
     * Get screen dimensions and density.
     */
    private void getScreenDimensions() {
        WindowManager windowManager = getSystemService(WindowManager.class);
        Display display = windowManager.getDefaultDisplay();
        DisplayMetrics metrics = new DisplayMetrics();
        display.getRealMetrics(metrics);
        
        screenWidth = metrics.widthPixels;
        screenHeight = metrics.heightPixels;
        screenDensity = metrics.densityDpi;
    }
    
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null) {
            MediaProjectionManager projectionManager = 
                getSystemService(MediaProjectionManager.class);
            
            int resultCode = intent.getIntExtra("resultCode", -1);
            Intent resultData = intent.getParcelableExtra("resultData");
            
            if (resultCode != -1 && resultData != null) {
                mediaProjection = projectionManager.getMediaProjection(resultCode, resultData);
                startCapture();
            }
        }
        
        return START_STICKY;
    }
    
    /**
     * Start screen capture.
     */
    private void startCapture() {
        if (mediaProjection == null) {
            return;
        }
        
        // Create ImageReader for frame capture
        imageReader = ImageReader.newInstance(
            screenWidth, screenHeight, PixelFormat.RGBA_8888, 2);
        
        // Create virtual display
        mediaProjection.createVirtualDisplay(
            "ScreenCapture",
            screenWidth, screenHeight, screenDensity,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_PUBLIC,
            imageReader.getSurface(),
            null, handler);
        
        isCapturing = true;
        startForeground(NOTIFICATION_ID, createNotification());
        captureFrame();
    }
    
    /**
     * Capture frames continuously.
     */
    private void captureFrame() {
        if (!isCapturing || imageReader == null) {
            return;
        }
        
        try {
            Image image = imageReader.acquireLatestImage();
            if (image != null) {
                Bitmap bitmap = imageToBitmap(image);
                image.close();
                
                if (bitmap != null && callback != null) {
                    callback.onFrameCaptured(bitmap);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        // Schedule next frame capture
        long delayMs = 1000 / FRAME_RATE;
        handler.postDelayed(this::captureFrame, delayMs);
    }
    
    /**
     * Convert Image to Bitmap.
     */
    private Bitmap imageToBitmap(Image image) {
        if (image.getFormat() != PixelFormat.RGBA_8888) {
            return null;
        }
        
        Image.Plane[] planes = image.getPlanes();
        ByteBuffer buffer = planes[0].getBuffer();
        int pixelStride = planes[0].getPixelStride();
        int width = image.getWidth();
        int height = image.getHeight();
        int rowPadding = planes[0].getRowPadding();
        
        Bitmap bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        
        int offset = 0;
        byte[] pixelData = new byte[buffer.remaining()];
        buffer.get(pixelData);
        
        for (int y = 0; y < height; ++y) {
            int pixelOffset = 0;
            for (int x = 0; x < width; ++x) {
                int r = pixelData[offset + pixelOffset] & 0xff;
                int g = pixelData[offset + pixelOffset + 1] & 0xff;
                int b = pixelData[offset + pixelOffset + 2] & 0xff;
                int a = pixelData[offset + pixelOffset + 3] & 0xff;
                
                bitmap.setPixel(x, y, (a << 24) | (r << 16) | (g << 8) | b);
                pixelOffset += pixelStride;
            }
            offset += rowPadding;
        }
        
        return bitmap;
    }
    
    /**
     * Set the callback for frame capture.
     */
    public void setCallback(ScreenCaptureCallback callback) {
        this.callback = callback;
    }
    
    /**
     * Stop screen capture.
     */
    public void stopCapture() {
        isCapturing = false;
        
        if (imageReader != null) {
            imageReader.close();
            imageReader = null;
        }
        
        if (mediaProjection != null) {
            mediaProjection.stop();
            mediaProjection = null;
        }
        
        if (callback != null) {
            callback.onCaptureStopped();
        }
        
        stopForeground(STOP_FOREGROUND_REMOVE);
        stopSelf();
    }
    
    /**
     * Create notification for foreground service.
     */
    private NotificationCompat.Notification createNotification() {
        return new NotificationCompat.Builder(this, "overlay_channel")
            .setContentTitle("Fisher Overlay")
            .setContentText("Capturing screen...")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build();
    }
    
    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
    
    @Override
    public void onDestroy() {
        stopCapture();
        super.onDestroy();
    }
}
