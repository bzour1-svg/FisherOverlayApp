package com.fisher.overlay;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.view.View;
import java.util.ArrayList;
import java.util.List;

/**
 * Custom view for rendering overlay markers on detected fish.
 * Displays targeting information, value indicators, and difficulty ratings.
 */
public class OverlayView extends View {
    private List<FishData> detectedFish;
    private FishData bestTarget;
    private Paint paintBestTarget;
    private Paint paintGoodTarget;
    private Paint paintNormalTarget;
    private Paint paintText;
    private Paint paintLine;
    private float screenWidth;
    private float screenHeight;
    
    public OverlayView(Context context) {
        super(context);
        initializePaints();
        this.detectedFish = new ArrayList<>();
    }
    
    /**
     * Initialize paint objects for drawing.
     */
    private void initializePaints() {
        // Paint for best target (gold/yellow)
        paintBestTarget = new Paint();
        paintBestTarget.setColor(Color.parseColor("#FFD700")); // Gold
        paintBestTarget.setStyle(Paint.Style.STROKE);
        paintBestTarget.setStrokeWidth(4);
        paintBestTarget.setAntiAlias(true);
        
        // Paint for good targets (green)
        paintGoodTarget = new Paint();
        paintGoodTarget.setColor(Color.parseColor("#00FF00")); // Green
        paintGoodTarget.setStyle(Paint.Style.STROKE);
        paintGoodTarget.setStrokeWidth(3);
        paintGoodTarget.setAntiAlias(true);
        
        // Paint for normal targets (cyan)
        paintNormalTarget = new Paint();
        paintNormalTarget.setColor(Color.parseColor("#00FFFF")); // Cyan
        paintNormalTarget.setStyle(Paint.Style.STROKE);
        paintNormalTarget.setStrokeWidth(2);
        paintNormalTarget.setAntiAlias(true);
        
        // Paint for text
        paintText = new Paint();
        paintText.setColor(Color.WHITE);
        paintText.setTextSize(14);
        paintText.setAntiAlias(true);
        paintText.setFakeBoldText(true);
        
        // Paint for movement prediction lines
        paintLine = new Paint();
        paintLine.setColor(Color.parseColor("#FF6600")); // Orange
        paintLine.setStyle(Paint.Style.STROKE);
        paintLine.setStrokeWidth(2);
        paintLine.setAntiAlias(true);
    }
    
    /**
     * Update the detected fish list.
     */
    public void updateFishData(List<FishData> fish, FishData best) {
        this.detectedFish = fish != null ? fish : new ArrayList<>();
        this.bestTarget = best;
        invalidate();
    }
    
    /**
     * Set screen dimensions.
     */
    public void setScreenDimensions(float width, float height) {
        this.screenWidth = width;
        this.screenHeight = height;
    }
    
    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        
        if (detectedFish == null || detectedFish.isEmpty()) {
            return;
        }
        
        // Draw all detected fish
        for (FishData fish : detectedFish) {
            if (fish == bestTarget) {
                drawBestTarget(canvas, fish);
            } else if (fish.valueRatio > 5) {
                drawGoodTarget(canvas, fish);
            } else {
                drawNormalTarget(canvas, fish);
            }
        }
    }
    
    /**
     * Draw the best target with prominent markers.
     */
    private void drawBestTarget(Canvas canvas, FishData fish) {
        float centerX = fish.getCenterX();
        float centerY = fish.getCenterY();
        float radius = Math.max(fish.width, fish.height) / 2 + 10;
        
        // Draw outer circle (pulsing effect simulation with multiple circles)
        canvas.drawCircle(centerX, centerY, radius, paintBestTarget);
        canvas.drawCircle(centerX, centerY, radius - 5, paintBestTarget);
        
        // Draw crosshair
        float crossSize = 30;
        canvas.drawLine(centerX - crossSize, centerY, centerX + crossSize, centerY, paintBestTarget);
        canvas.drawLine(centerX, centerY - crossSize, centerX, centerY + crossSize, paintBestTarget);
        
        // Draw bounding box
        canvas.drawRect(fish.x, fish.y, fish.x + fish.width, fish.y + fish.height, paintBestTarget);
        
        // Draw info text
        String info = String.format("%s (%d💎)", fish.nameAr, fish.value);
        canvas.drawText(info, fish.x, fish.y - 10, paintText);
        
        // Draw value-to-difficulty ratio
        String ratio = String.format("Ratio: %.2f", fish.valueRatio);
        canvas.drawText(ratio, fish.x, fish.y + fish.height + 20, paintText);
        
        // Draw movement prediction line
        if (fish.velocityX != 0 || fish.velocityY != 0) {
            float predictX = centerX + fish.velocityX * 0.5f; // Predict 0.5 seconds ahead
            float predictY = centerY + fish.velocityY * 0.5f;
            canvas.drawLine(centerX, centerY, predictX, predictY, paintLine);
            canvas.drawCircle(predictX, predictY, 5, paintLine);
        }
    }
    
    /**
     * Draw a good target with medium prominence.
     */
    private void drawGoodTarget(Canvas canvas, FishData fish) {
        float centerX = fish.getCenterX();
        float centerY = fish.getCenterY();
        float radius = Math.max(fish.width, fish.height) / 2 + 5;
        
        // Draw circle
        canvas.drawCircle(centerX, centerY, radius, paintGoodTarget);
        
        // Draw bounding box
        canvas.drawRect(fish.x, fish.y, fish.x + fish.width, fish.y + fish.height, paintGoodTarget);
        
        // Draw simple info
        String info = String.format("%s (%d💎)", fish.nameAr, fish.value);
        canvas.drawText(info, fish.x, fish.y - 5, paintText);
    }
    
    /**
     * Draw a normal target with minimal markers.
     */
    private void drawNormalTarget(Canvas canvas, FishData fish) {
        // Draw simple circle
        float centerX = fish.getCenterX();
        float centerY = fish.getCenterY();
        float radius = Math.max(fish.width, fish.height) / 2 + 2;
        
        canvas.drawCircle(centerX, centerY, radius, paintNormalTarget);
        
        // Draw small label
        canvas.drawText(fish.nameAr, fish.x, fish.y - 2, paintText);
    }
    
    /**
     * Clear all overlays.
     */
    public void clear() {
        this.detectedFish = new ArrayList<>();
        this.bestTarget = null;
        invalidate();
    }
}
