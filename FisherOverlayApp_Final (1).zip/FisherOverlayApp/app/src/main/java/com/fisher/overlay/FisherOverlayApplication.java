package com.fisher.overlay;

import android.app.Application;

/**
 * Application class for Fisher Overlay.
 * Initializes global resources and notification channels.
 */
public class FisherOverlayApplication extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        
        // Create notification channels
        NotificationManager.createNotificationChannels(this);
        
        // Initialize fish database
        FishDatabase.getInstance();
    }
}
