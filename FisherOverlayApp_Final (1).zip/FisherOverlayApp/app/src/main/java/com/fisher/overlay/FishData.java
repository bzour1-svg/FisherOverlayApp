package com.fisher.overlay;

/**
 * Data class representing a fish in the game.
 * Contains all information needed for detection, tracking, and analysis.
 */
public class FishData {
    public int id;
    public String nameAr;
    public String nameEn;
    public int value;
    public String category; // "small", "medium", "high"
    public String colorPrimary;
    public String description;
    
    // Detection and tracking data
    public float x; // Screen X coordinate
    public float y; // Screen Y coordinate
    public float width; // Bounding box width
    public float height; // Bounding box height
    public float confidence; // Detection confidence (0-1)
    public float velocityX; // Movement velocity X
    public float velocityY; // Movement velocity Y
    
    // Analysis data
    public float difficulty; // Calculated difficulty (1.0 - 3.0)
    public float valueRatio; // value / difficulty
    public long lastSeenTime; // Timestamp of last detection
    
    // Advanced movement tracking
    public float actualSpeed; // Calculated speed in pixels/second
    public float trajectoryStability; // How predictable the movement is (0-1)
    public boolean isMovingTowardEdge; // Is fish leaving screen
    public long firstDetectedTime; // When fish was first detected
    
    public FishData() {
        this.x = 0;
        this.y = 0;
        this.width = 0;
        this.height = 0;
        this.confidence = 0;
        this.velocityX = 0;
        this.velocityY = 0;
        this.difficulty = 1.0f;
        this.valueRatio = 0;
        this.lastSeenTime = System.currentTimeMillis();
        this.actualSpeed = 0.0f;
        this.trajectoryStability = 0.5f;
        this.isMovingTowardEdge = false;
        this.firstDetectedTime = System.currentTimeMillis();
    }
    
    /**
     * Calculate the value-to-difficulty ratio for this fish.
     * Higher ratio = better target.
     */
    public void calculateRatio() {
        if (difficulty > 0) {
            this.valueRatio = (float) value / difficulty;
        }
    }
    
    /**
     * Predict the next position based on velocity.
     */
    public void predictNextPosition(long deltaTimeMs) {
        float deltaTimeSec = deltaTimeMs / 1000.0f;
        this.x += velocityX * deltaTimeSec;
        this.y += velocityY * deltaTimeSec;
    }
    
    /**
     * Get the center point of the fish bounding box.
     */
    public float getCenterX() {
        return x + width / 2;
    }
    
    public float getCenterY() {
        return y + height / 2;
    }
    
    @Override
    public String toString() {
        return String.format("%s (ID: %d, Value: %d, Ratio: %.2f)", 
            nameAr, id, value, valueRatio);
    }
}
