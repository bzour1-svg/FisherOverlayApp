package com.fisher.overlay;

import android.app.Service;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.IBinder;
import android.view.Gravity;
import android.view.WindowManager;
import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;
import java.util.List;

/**
 * Main overlay service that manages screen capture, fish detection, and overlay rendering.
 * Runs as a foreground service and coordinates all overlay components.
 */
public class OverlayService extends Service implements ScreenCaptureService.ScreenCaptureCallback {
    private static final String TAG = "OverlayService";
    private static final int NOTIFICATION_ID = 1000;
    
    private OverlayView overlayView;
    private WindowManager windowManager;
    private WindowManager.LayoutParams layoutParams;
    private FishDetector fishDetector;
    private ScreenCaptureService screenCaptureService;
    private boolean isRunning = false;
    
    @Override
    public void onCreate() {
        super.onCreate();
        windowManager = getSystemService(WindowManager.class);
        fishDetector = new FishDetector();
        createOverlayView();
    }
    
    /**
     * Create and configure the overlay view.
     */
    private void createOverlayView() {
        overlayView = new OverlayView(this);
        
        layoutParams = new WindowManager.LayoutParams();
        layoutParams.type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O ?
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY :
            WindowManager.LayoutParams.TYPE_PHONE;
        layoutParams.format = PixelFormat.TRANSLUCENT;
        layoutParams.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                           WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE |
                           WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS;
        layoutParams.gravity = Gravity.TOP | Gravity.LEFT;
        layoutParams.width = WindowManager.LayoutParams.MATCH_PARENT;
        layoutParams.height = WindowManager.LayoutParams.MATCH_PARENT;
        layoutParams.x = 0;
        layoutParams.y = 0;
    }
    
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (!isRunning) {
            startForeground(NOTIFICATION_ID, createNotification());
            windowManager.addView(overlayView, layoutParams);
            isRunning = true;
        }
        
        return START_STICKY;
    }
    
    /**
     * Start the screen capture service.
     */
    public void startScreenCapture(int resultCode, Intent resultData) {
        Intent captureIntent = new Intent(this, ScreenCaptureService.class);
        captureIntent.putExtra("resultCode", resultCode);
        captureIntent.putExtra("resultData", resultData);
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(captureIntent);
        } else {
            startService(captureIntent);
        }
    }
    
    /**
     * Stop the overlay service.
     */
    public void stopOverlay() {
        if (overlayView != null && isRunning) {
            try {
                windowManager.removeView(overlayView);
            } catch (Exception e) {
                e.printStackTrace();
            }
            isRunning = false;
        }
        stopForeground(STOP_FOREGROUND_REMOVE);
        stopSelf();
    }
    
    @Override
    public void onFrameCaptured(Bitmap frame) {
        if (frame == null || !isRunning) {
            return;
        }
        
        try {
            // Detect fish in the frame
            List<FishData> detectedFish = fishDetector.detectFish(frame);
            
            // Get the best target
            FishData bestTarget = fishDetector.getBestTarget(detectedFish);
            
            // Update overlay
            overlayView.updateFishData(detectedFish, bestTarget);
            overlayView.setScreenDimensions(frame.getWidth(), frame.getHeight());
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    @Override
    public void onCaptureStopped() {
        stopOverlay();
    }
    
    /**
     * Create notification for foreground service.
     */
    private NotificationCompat.Notification createNotification() {
        return new NotificationCompat.Builder(this, "overlay_channel")
            .setContentTitle("Fisher Overlay Active")
            .setContentText("Analyzing fish in real-time")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build();
    }
    
    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
    
    @Override
    public void onDestroy() {
        stopOverlay();
        super.onDestroy();
    }
}
