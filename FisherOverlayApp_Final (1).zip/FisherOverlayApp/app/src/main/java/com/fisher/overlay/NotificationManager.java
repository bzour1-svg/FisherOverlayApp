package com.fisher.overlay;

import android.app.NotificationChannel;
import android.content.Context;
import android.os.Build;

/**
 * Manages notification channels for the overlay service.
 */
public class NotificationManager {
    private static final String OVERLAY_CHANNEL_ID = "overlay_channel";
    private static final String OVERLAY_CHANNEL_NAME = "Fisher Overlay";
    
    public static void createNotificationChannels(Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            android.app.NotificationManager notificationManager = 
                context.getSystemService(android.app.NotificationManager.class);
            
            NotificationChannel overlayChannel = new NotificationChannel(
                OVERLAY_CHANNEL_ID,
                OVERLAY_CHANNEL_NAME,
                android.app.NotificationManager.IMPORTANCE_LOW);
            overlayChannel.setDescription("Notifications for Fisher Overlay service");
            
            notificationManager.createNotificationChannel(overlayChannel);
        }
    }
    
    public static String getOverlayChannelId() {
        return OVERLAY_CHANNEL_ID;
    }
}
