package com.fisher.overlay;

import android.graphics.Bitmap;
import android.graphics.Color;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Fish detection engine using color-based detection and pattern recognition.
 * Analyzes frames to identify fish, their positions, and characteristics.
 */
public class FishDetector {
    private static final String TAG = "FishDetector";
    private FishDatabase fishDatabase;
    private Map<Integer, FishData> trackedFish;
    private static final float CONFIDENCE_THRESHOLD = 0.5f;
    private static final int MIN_FISH_SIZE = 20; // Minimum pixels
    
    // Color ranges for different fish types (HSV)
    private Map<String, ColorRange> colorRanges;
    
    public FishDetector() {
        this.fishDatabase = FishDatabase.getInstance();
        this.trackedFish = new HashMap<>();
        initializeColorRanges();
    }
    
    /**
     * Initialize color detection ranges for different fish types.
     */
    private void initializeColorRanges() {
        colorRanges = new HashMap<>();
        
        // Purple/Magenta fish
        colorRanges.put("purple", new ColorRange(280, 320, 30, 100, 40, 100));
        
        // Green fish
        colorRanges.put("green", new ColorRange(80, 140, 30, 100, 40, 100));
        
        // Red/Pink fish
        colorRanges.put("red", new ColorRange(0, 30, 30, 100, 40, 100));
        colorRanges.put("red_alt", new ColorRange(330, 360, 30, 100, 40, 100));
        
        // Blue fish
        colorRanges.put("blue", new ColorRange(200, 260, 30, 100, 40, 100));
        
        // Golden/Yellow fish
        colorRanges.put("golden", new ColorRange(40, 60, 30, 100, 50, 100));
        
        // Colorful/Mixed
        colorRanges.put("colorful", new ColorRange(0, 360, 20, 100, 30, 100));
    }
    
    /**
     * Detect fish in a bitmap frame.
     */
    public List<FishData> detectFish(Bitmap frame) {
        if (frame == null) {
            return new ArrayList<>();
        }
        
        List<FishData> detectedFish = new ArrayList<>();
        
        try {
            // Convert bitmap to HSV for color detection
            int width = frame.getWidth();
            int height = frame.getHeight();
            int[] pixels = new int[width * height];
            frame.getPixels(pixels, 0, width, 0, 0, width, height);
            
            // Detect colored regions
            List<FishRegion> regions = detectColoredRegions(pixels, width, height);
            
            // Match regions to fish types
            for (FishRegion region : regions) {
                FishData fish = matchRegionToFish(region, width, height);
                if (fish != null && fish.confidence >= CONFIDENCE_THRESHOLD) {
                    detectedFish.add(fish);
                }
            }
            
            // Update tracking
            updateTracking(detectedFish);
            
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return detectedFish;
    }
    
    /**
     * Detect colored regions in the frame.
     */
    private List<FishRegion> detectColoredRegions(int[] pixels, int width, int height) {
        List<FishRegion> regions = new ArrayList<>();
        boolean[] visited = new boolean[pixels.length];
        
        for (int i = 0; i < pixels.length; i++) {
            if (!visited[i] && isSignificantColor(pixels[i])) {
                FishRegion region = floodFill(pixels, visited, i, width, height);
                if (region != null && region.size >= MIN_FISH_SIZE) {
                    regions.add(region);
                }
            }
        }
        
        return regions;
    }
    
    /**
     * Check if a pixel has a significant color (not background).
     */
    private boolean isSignificantColor(int pixel) {
        int r = Color.red(pixel);
        int g = Color.green(pixel);
        int b = Color.blue(pixel);
        
        // Filter out very dark or very light pixels (likely background)
        int brightness = (r + g + b) / 3;
        if (brightness < 30 || brightness > 240) {
            return false;
        }
        
        // Check for color saturation
        int max = Math.max(r, Math.max(g, b));
        int min = Math.min(r, Math.min(g, b));
        int saturation = (max - min);
        
        return saturation > 20; // Has color, not grayscale
    }
    
    /**
     * Flood fill algorithm to find connected regions.
     */
    private FishRegion floodFill(int[] pixels, boolean[] visited, int startIdx, 
                                 int width, int height) {
        FishRegion region = new FishRegion();
        List<Integer> queue = new ArrayList<>();
        queue.add(startIdx);
        visited[startIdx] = true;
        
        int baseColor = pixels[startIdx];
        int minX = startIdx % width;
        int maxX = minX;
        int minY = startIdx / width;
        int maxY = minY;
        
        while (!queue.isEmpty()) {
            int idx = queue.remove(0);
            int x = idx % width;
            int y = idx / width;
            
            region.pixels.add(idx);
            region.size++;
            
            minX = Math.min(minX, x);
            maxX = Math.max(maxX, x);
            minY = Math.min(minY, y);
            maxY = Math.max(maxY, y);
            
            // Check neighbors
            int[] neighbors = {idx - 1, idx + 1, idx - width, idx + width};
            for (int neighbor : neighbors) {
                if (neighbor >= 0 && neighbor < pixels.length && !visited[neighbor]) {
                    if (colorSimilar(pixels[neighbor], baseColor)) {
                        visited[neighbor] = true;
                        queue.add(neighbor);
                    }
                }
            }
        }
        
        region.x = minX;
        region.y = minY;
        region.width = maxX - minX + 1;
        region.height = maxY - minY + 1;
        region.centerX = (minX + maxX) / 2.0f;
        region.centerY = (minY + maxY) / 2.0f;
        region.dominantColor = baseColor;
        
        return region;
    }
    
    /**
     * Check if two colors are similar.
     */
    private boolean colorSimilar(int color1, int color2) {
        int r1 = Color.red(color1);
        int g1 = Color.green(color1);
        int b1 = Color.blue(color1);
        
        int r2 = Color.red(color2);
        int g2 = Color.green(color2);
        int b2 = Color.blue(color2);
        
        int diff = Math.abs(r1 - r2) + Math.abs(g1 - g2) + Math.abs(b1 - b2);
        return diff < 60; // Threshold for color similarity
    }
    
    /**
     * Match a detected region to a fish type.
     */
    private FishData matchRegionToFish(FishRegion region, int screenWidth, int screenHeight) {
        String colorType = detectColorType(region.dominantColor);
        List<FishData> candidates = new ArrayList<>();
        
        // Get fish with matching color
        for (FishData fish : fishDatabase.getAllFish()) {
            if (fish.colorPrimary.equalsIgnoreCase(colorType) || 
                colorType.equals("colorful")) {
                candidates.add(fish);
            }
        }
        
        if (candidates.isEmpty()) {
            return null;
        }
        
        // Estimate fish based on size and position
        FishData bestMatch = candidates.get(0);
        
        // Estimate difficulty based on size
        float sizeRatio = (float) region.size / (screenWidth * screenHeight);
        if (sizeRatio < 0.01f) {
            bestMatch.difficulty = 1.0f; // Small = easy
        } else if (sizeRatio < 0.05f) {
            bestMatch.difficulty = 1.5f; // Medium
        } else {
            bestMatch.difficulty = 2.5f; // Large = hard
        }
        
        bestMatch.x = region.x;
        bestMatch.y = region.y;
        bestMatch.width = region.width;
        bestMatch.height = region.height;
        bestMatch.confidence = 0.7f; // Base confidence
        bestMatch.lastSeenTime = System.currentTimeMillis();
        bestMatch.calculateRatio();
        
        return bestMatch;
    }
    
    /**
     * Detect color type from RGB.
     */
    private String detectColorType(int color) {
        int r = Color.red(color);
        int g = Color.green(color);
        int b = Color.blue(color);
        
        // Simple color detection
        if (r > 150 && g < 100 && b < 100) {
            return "red";
        } else if (r < 100 && g > 150 && b < 100) {
            return "green";
        } else if (r < 100 && g < 100 && b > 150) {
            return "blue";
        } else if (r > 150 && g > 100 && b < 100) {
            return "golden";
        } else if (r > 100 && g < 100 && b > 100) {
            return "purple";
        }
        return "colorful";
    }
    
    /**
     * Update tracking of fish across frames.
     */
    private void updateTracking(List<FishData> currentFish) {
        // Simple tracking: match by proximity
        for (FishData fish : currentFish) {
            FishData tracked = trackedFish.get(fish.id);
            if (tracked != null) {
                // Calculate velocity
                long timeDiff = fish.lastSeenTime - tracked.lastSeenTime;
                if (timeDiff > 0) {
                    fish.velocityX = (fish.x - tracked.x) / (timeDiff / 1000.0f);
                    fish.velocityY = (fish.y - tracked.y) / (timeDiff / 1000.0f);
                }
            }
            trackedFish.put(fish.id, fish);
        }
    }
    
    /**
     * Get the best target fish based on value-to-difficulty ratio.
     */
    public FishData getBestTarget(List<FishData> detectedFish) {
        if (detectedFish.isEmpty()) {
            return null;
        }
        
        // Sort by value-to-difficulty ratio
        Collections.sort(detectedFish, (a, b) -> 
            Float.compare(b.valueRatio, a.valueRatio));
        
        return detectedFish.get(0);
    }
    
    /**
     * Get top N targets.
     */
    public List<FishData> getTopTargets(List<FishData> detectedFish, int count) {
        if (detectedFish.isEmpty()) {
            return new ArrayList<>();
        }
        
        Collections.sort(detectedFish, (a, b) -> 
            Float.compare(b.valueRatio, a.valueRatio));
        
        return detectedFish.subList(0, Math.min(count, detectedFish.size()));
    }
    
    /**
     * Inner class for color range definition.
     */
    private static class ColorRange {
        float hMin, hMax, sMin, sMax, vMin, vMax;
        
        ColorRange(float hMin, float hMax, float sMin, float sMax, 
                  float vMin, float vMax) {
            this.hMin = hMin;
            this.hMax = hMax;
            this.sMin = sMin;
            this.sMax = sMax;
            this.vMin = vMin;
            this.vMax = vMax;
        }
    }
    
    /**
     * Inner class for detected region.
     */
    private static class FishRegion {
        List<Integer> pixels = new ArrayList<>();
        int size = 0;
        int x, y, width, height;
        float centerX, centerY;
        int dominantColor;
    }
}
