package com.fisher.overlay;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

/**
 * Main activity for the Fisher Overlay application.
 * Handles permissions, UI controls, and service management.
 */
public class MainActivity extends AppCompatActivity {
    private static final String TAG = "MainActivity";
    private static final int PERMISSION_REQUEST_CODE = 1001;
    private static final int MEDIA_PROJECTION_REQUEST_CODE = 1002;
    
    private Button btnStartOverlay;
    private Button btnStopOverlay;
    private Button btnSettings;
    private TextView tvStatus;
    private OverlayService overlayService;
    private MediaProjectionManager mediaProjectionManager;
    private boolean isOverlayRunning = false;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        initializeUI();
        mediaProjectionManager = getSystemService(MediaProjectionManager.class);
        checkAndRequestPermissions();
    }
    
    /**
     * Initialize UI components.
     */
    private void initializeUI() {
        btnStartOverlay = findViewById(R.id.btnStartOverlay);
        btnStopOverlay = findViewById(R.id.btnStopOverlay);
        btnSettings = findViewById(R.id.btnSettings);
        tvStatus = findViewById(R.id.tvStatus);
        
        btnStartOverlay.setOnClickListener(v -> startOverlay());
        btnStopOverlay.setOnClickListener(v -> stopOverlay());
        btnSettings.setOnClickListener(v -> openSettings());
        
        updateStatusUI();
    }
    
    /**
     * Check and request necessary permissions.
     */
    private void checkAndRequestPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (ContextCompat.checkSelfPermission(this, 
                Manifest.permission.SYSTEM_ALERT_WINDOW) 
                != PackageManager.PERMISSION_GRANTED) {
                
                ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.SYSTEM_ALERT_WINDOW},
                    PERMISSION_REQUEST_CODE);
            }
        }
    }
    
    /**
     * Start the overlay.
     */
    private void startOverlay() {
        if (isOverlayRunning) {
            Toast.makeText(this, "Overlay already running", Toast.LENGTH_SHORT).show();
            return;
        }
        
        // Request MediaProjection permission
        Intent intent = mediaProjectionManager.createScreenCaptureIntent();
        startActivityForResult(intent, MEDIA_PROJECTION_REQUEST_CODE);
    }
    
    /**
     * Stop the overlay.
     */
    private void stopOverlay() {
        if (!isOverlayRunning) {
            Toast.makeText(this, "Overlay not running", Toast.LENGTH_SHORT).show();
            return;
        }
        
        if (overlayService != null) {
            overlayService.stopOverlay();
        }
        
        isOverlayRunning = false;
        updateStatusUI();
        Toast.makeText(this, "Overlay stopped", Toast.LENGTH_SHORT).show();
    }
    
    /**
     * Open settings activity.
     */
    private void openSettings() {
        Toast.makeText(this, "Settings coming soon", Toast.LENGTH_SHORT).show();
    }
    
    /**
     * Update status UI.
     */
    private void updateStatusUI() {
        if (isOverlayRunning) {
            tvStatus.setText("Status: Overlay Running");
            tvStatus.setTextColor(getColor(android.R.color.holo_green_dark));
            btnStartOverlay.setEnabled(false);
            btnStopOverlay.setEnabled(true);
        } else {
            tvStatus.setText("Status: Idle");
            tvStatus.setTextColor(getColor(android.R.color.darker_gray));
            btnStartOverlay.setEnabled(true);
            btnStopOverlay.setEnabled(false);
        }
    }
    
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        
        if (requestCode == MEDIA_PROJECTION_REQUEST_CODE) {
            if (resultCode == Activity.RESULT_OK && data != null) {
                // Start overlay service
                Intent overlayIntent = new Intent(this, OverlayService.class);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    startForegroundService(overlayIntent);
                } else {
                    startService(overlayIntent);
                }
                
                // Start screen capture
                if (overlayService == null) {
                    overlayService = new OverlayService();
                }
                overlayService.startScreenCapture(resultCode, data);
                
                isOverlayRunning = true;
                updateStatusUI();
                Toast.makeText(this, "Overlay started", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Permission denied", Toast.LENGTH_SHORT).show();
            }
        }
    }
    
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, 
                                          @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        
        if (requestCode == PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && 
                grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Permission granted", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Permission denied", Toast.LENGTH_SHORT).show();
            }
        }
    }
    
    @Override
    protected void onDestroy() {
        if (isOverlayRunning) {
            stopOverlay();
        }
        super.onDestroy();
    }
}
