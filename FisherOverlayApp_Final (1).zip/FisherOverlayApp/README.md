# 🎮 Fisher Likee Overlay Assistant

تطبيق أندرويد متقدم يعمل كطبقة فوقية ذكية على لعبة "Fisher Likee" لتحليل الأسماك وتقديم توصيات تصويب فوري.

## ✨ المميزات الرئيسية

### 🎯 تحليل ذكي للأسماك
- كشف فوري لجميع أنواع الأسماك الـ 12
- حساب نسبة القيمة إلى الصعوبة لكل سمكة
- تحديد الهدف الأفضل تلقائياً

### 📊 معالجة متقدمة
- التقاط الشاشة في الوقت الفعلي (15 FPS)
- معالجة الألوان والأنماط
- تتبع حركة الأسماك عبر الإطارات

### 🎨 واجهة بصرية
- مؤشرات ذهبية للأهداف الأفضل
- مؤشرات خضراء للأهداف الجيدة
- خطوط التنبؤ بالحركة
- عدم إعاقة اللعبة

### 📱 متوافق مع
- Android 6.0+ (API 24+)
- جميع أحجام الشاشات
- الأجهزة بمعالجات مختلفة

## 🐠 أنواع الأسماك المدعومة

| الرقم | الاسم العربي | الاسم الإنجليزي | القيمة | النوع |
|------|-------------|-----------------|--------|-------|
| 1 | قنديل البحر | Jellyfish | 3 ماس | صغيرة |
| 2 | سلحفاة البحر | Sea Turtle | 3 ماس | صغيرة |
| 3 | السمكة الحمراء | Red Fish | 4 ماس | صغيرة |
| 4 | الدولفين الذهبي | Golden Dolphin | 4 ماس | صغيرة |
| 5 | السمكة الشريرة | Evil Fish | 5 ماس | صغيرة |
| 6 | سمكة كبيرة شريرة | Big Evil Fish | 5 ماس | متوسطة |
| 7 | قنديل البحر الذهبي | Golden Jellyfish | 8 ماس | متوسطة |
| 8 | السلحفاة الذهبية | Golden Turtle | 10 ماس | متوسطة |
| 9 | سمك القرش الذهبي | Golden Shark | 12 ماس | متوسطة |
| 10 | تمساح | Crocodile | 12 ماس | متوسطة |
| 11 | قرش | Shark | 30 ماس | كبيرة |
| 12 | ملك التنين | Dragon King | 40 ماس | كبيرة |

## 🚀 البدء السريع

### المتطلبات
- Android Studio 2023.1+
- Android SDK API 34
- Java 11+
- Gradle 8.1+

### التثبيت

```bash
# استنساخ المشروع
git clone https://github.com/yourusername/FisherOverlay.git
cd FisherOverlayApp

# بناء APK
./gradlew assembleDebug

# تثبيت على الجهاز
adb install app/build/outputs/apk/debug/app-debug.apk
```

### الاستخدام

1. افتح لعبة Fisher Likee
2. افتح تطبيق Fisher Overlay
3. اضغط "Start Overlay"
4. منح الأذونات المطلوبة
5. شاهد المؤشرات على الأسماك!

## 🏗️ البنية المعمارية

```
┌─────────────────────────────────────┐
│      MainActivity (الواجهة)          │
└────────────────┬────────────────────┘
                 │
    ┌────────────┼────────────┐
    │            │            │
┌───▼────┐  ┌───▼────┐  ┌───▼────┐
│Overlay │  │Screen  │  │Fish    │
│Service │  │Capture │  │Analysis│
│        │  │Service │  │Engine  │
└───┬────┘  └───┬────┘  └───┬────┘
    │           │           │
    └───────────┼───────────┘
                │
        ┌───────▼────────┐
        │ FishDetector   │
        │ & Database     │
        └────────────────┘
```

## 🔧 المكونات الرئيسية

### `MainActivity.java`
- نقطة الدخول الرئيسية
- إدارة الأذونات
- التحكم في بدء/إيقاف الخدمة

### `OverlayService.java`
- إدارة الطبقة الفوقية
- تنسيق بين الخدمات
- معالجة الإطارات

### `ScreenCaptureService.java`
- التقاط الشاشة باستخدام MediaProjection
- إرسال الإطارات للمعالجة
- إدارة الموارد

### `FishDetector.java`
- كشف الأسماك بناءً على الألوان
- معالجة الصور
- تتبع الحركة

### `FishAnalysisEngine.java`
- حساب نسب القيمة/الصعوبة
- التنبؤ بالحركة
- اختيار الأهداف المثالية

### `FishDatabase.java`
- قاعدة بيانات جميع أنواع الأسماك
- معلومات القيمة والصعوبة
- البحث والتصفية

### `OverlayView.java`
- رسم المؤشرات على الشاشة
- عرض المعلومات
- تحديث الرسومات

## 📊 خوارزميات التحليل

### حساب نسبة القيمة/الصعوبة

```
Ratio = Value / Difficulty

حيث:
- Value = عدد الماسات من السمكة
- Difficulty = عامل الصعوبة (1.0-2.5)
  - 1.0 = سهلة جداً (صغيرة، بطيئة)
  - 1.5 = متوسطة
  - 2.5 = صعبة جداً (كبيرة، سريعة)
```

### تتبع الحركة

يستخدم التطبيق معالجة الإطارات المتعددة لـ:
- حساب السرعة (بكسل/ثانية)
- تحديد الاتجاه
- التنبؤ بالموضع التالي

### الكشف بناءً على الألوان

- تحويل RGB إلى HSV
- مطابقة النطاقات اللونية
- تجميع البكسلات المتشابهة
- تحديد مركز السمكة

## ⚙️ الأداء

- **معدل الإطارات**: 15 FPS (قابل للتعديل)
- **زمن الكمون**: <100ms من الالتقاط إلى العرض
- **استهلاك الذاكرة**: ~50-100 MB
- **استهلاك البطارية**: معتدل
- **دعم الأجهزة**: من Snapdragon 630 فما فوق

## 🔐 الأذونات المطلوبة

```xml
<uses-permission android:name="android.permission.SYSTEM_ALERT_WINDOW" />
<uses-permission android:name="android.permission.FOREGROUND_SERVICE" />
<uses-permission android:name="android.permission.FOREGROUND_SERVICE_MEDIA_PROJECTION" />
```

## 📝 الملفات الرئيسية

```
FisherOverlayApp/
├── app/src/main/
│   ├── java/com/fisher/overlay/
│   │   ├── MainActivity.java
│   │   ├── OverlayService.java
│   │   ├── ScreenCaptureService.java
│   │   ├── FishDetector.java
│   │   ├── FishAnalysisEngine.java
│   │   ├── FishDatabase.java
│   │   ├── FishData.java
│   │   ├── OverlayView.java
│   │   ├── NotificationManager.java
│   │   └── FisherOverlayApplication.java
│   └── res/
│       ├── layout/activity_main.xml
│       └── values/
│           ├── strings.xml
│           ├── colors.xml
│           ├── styles.xml
│           └── dimens.xml
├── build.gradle
├── settings.gradle
└── README.md
```

## 🐛 استكشاف الأخطاء

### لا يتم الكشف عن الأسماك
- تحقق من الإضاءة
- تأكد من أن اللعبة في المقدمة
- جرب ضبط نطاقات الألوان

### الأداء بطيء
- قلل معدل الإطارات
- أغلق التطبيقات الأخرى
- استخدم جهازاً أقوى

### الطبقة الفوقية لا تظهر
- تحقق من الأذونات
- أعد تشغيل التطبيق
- تحقق من Logcat للأخطاء

## 📚 الموارد الإضافية

- [Android Developer Docs](https://developer.android.com)
- [MediaProjection API](https://developer.android.com/reference/android/media/projection/MediaProjection)
- [Canvas Drawing](https://developer.android.com/reference/android/graphics/Canvas)

## 📄 الترخيص

هذا المشروع مخصص للاستخدام التعليمي والشخصي. يرجى احترام شروط خدمة اللعبة الأصلية.

## 👨‍💻 المساهمة

نرحب بالمساهمات! يرجى:
1. عمل Fork للمشروع
2. إنشاء فرع للميزة الجديدة
3. إرسال Pull Request

## 📧 التواصل

للأسئلة والاقتراحات، يرجى فتح Issue أو التواصل عبر البريد الإلكتروني.

---

**ملاحظة**: هذا التطبيق مخصص للاستخدام التعليمي فقط. استخدام أي أداة مساعدة قد ينتهك شروط الخدمة.

**الإصدار**: 1.0  
**آخر تحديث**: مايو 2026
