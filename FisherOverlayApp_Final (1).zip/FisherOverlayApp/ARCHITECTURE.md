# 🏗️ البنية المعمارية - Fisher Likee Overlay

## نظرة عامة

يتبع التطبيق معمارية **Service-Oriented** مع فصل واضح بين المسؤوليات:

```
┌─────────────────────────────────────────────────────────────┐
│                    MainActivity (UI Layer)                   │
│                  - واجهة المستخدم الرئيسية                  │
│                  - إدارة الأذونات                           │
│                  - التحكم في الخدمات                        │
└────────────────────────────┬────────────────────────────────┘
                             │
        ┌────────────────────┼────────────────────┐
        │                    │                    │
┌───────▼────────┐  ┌────────▼────────┐  ┌──────▼──────────┐
│ OverlayService │  │ScreenCapture    │  │ FishAnalysis    │
│                │  │ Service         │  │ Engine          │
│ - Overlay Mgmt │  │                 │  │                 │
│ - Coordination │  │ - Screen Capture│  │ - Analysis      │
│ - Frame Update │  │ - Frame Delivery│  │ - Ranking       │
└────────┬───────┘  └────────┬────────┘  └──────┬──────────┘
         │                   │                   │
         └───────────────────┼───────────────────┘
                             │
                    ┌────────▼────────┐
                    │  FishDetector   │
                    │                 │
                    │ - Color Analysis│
                    │ - Pattern Match │
                    │ - Tracking      │
                    └────────┬────────┘
                             │
                    ┌────────▼────────┐
                    │  FishDatabase   │
                    │                 │
                    │ - Fish Data     │
                    │ - Lookup Tables │
                    │ - Difficulty    │
                    └─────────────────┘
```

---

## طبقات التطبيق

### 1. طبقة العرض (UI Layer)

#### `MainActivity.java`
- **المسؤولية**: واجهة المستخدم الرئيسية
- **المهام**:
  - عرض أزرار التحكم
  - طلب الأذونات
  - إدارة دورة حياة الخدمات
  - عرض حالة التطبيق

**الفئات المستخدمة**:
```java
- Button: للتحكم
- TextView: لعرض الحالة
- Intent: لبدء الخدمات
- ActivityCompat: لطلب الأذونات
```

#### `OverlayView.java`
- **المسؤولية**: رسم المؤشرات على الشاشة
- **المهام**:
  - رسم دوائر حول الأسماك
  - عرض المعلومات
  - رسم خطوط التنبؤ
  - تحديث الرسومات

**الفئات المستخدمة**:
```java
- Canvas: للرسم
- Paint: لتنسيق الرسم
- View: للعرض
```

---

### 2. طبقة الخدمات (Service Layer)

#### `OverlayService.java`
- **المسؤولية**: إدارة الطبقة الفوقية
- **المهام**:
  - إنشاء وإدارة OverlayView
  - تنسيق بين الخدمات
  - معالجة الإطارات
  - تحديث الرسومات

**العلاقات**:
```
OverlayService
├── يدير OverlayView
├── ينسق مع ScreenCaptureService
├── ينسق مع FishAnalysisEngine
└── يستدعي FishDetector
```

#### `ScreenCaptureService.java`
- **المسؤولية**: التقاط الشاشة
- **المهام**:
  - استخدام MediaProjection API
  - التقاط الإطارات
  - تحويل الصور
  - إرسال الإطارات للمعالجة

**العلاقات**:
```
ScreenCaptureService
├── يستخدم MediaProjection
├── ينتج Bitmap frames
├── يرسل إلى callback
└── يدير ImageReader
```

---

### 3. طبقة المعالجة (Processing Layer)

#### `FishDetector.java`
- **المسؤولية**: كشف الأسماك
- **المهام**:
  - تحليل الألوان
  - كشف المناطق الملونة
  - مطابقة الأسماك
  - تتبع الحركة

**الخوارزميات**:
```
1. تحويل RGB → HSV
2. كشف الألوان الهامة
3. Flood Fill للمناطق المتصلة
4. حساب مركز السمكة
5. مطابقة مع قاعدة البيانات
```

#### `FishAnalysisEngine.java`
- **المسؤولية**: تحليل الأسماك
- **المهام**:
  - حساب نسب القيمة/الصعوبة
  - التنبؤ بالحركة
  - اختيار الأهداف المثالية
  - تتبع التاريخ

**الحسابات**:
```
Ratio = Value / Difficulty
Score = (Value × 0.4) + (Ratio × 0.4) + (1/Difficulty × 0.2)
```

---

### 4. طبقة البيانات (Data Layer)

#### `FishDatabase.java`
- **المسؤولية**: إدارة بيانات الأسماك
- **المهام**:
  - تخزين معلومات الأسماك
  - توفير واجهات البحث
  - إدارة عوامل الصعوبة

**البيانات المخزنة**:
```java
- Fish ID (1-12)
- Arabic/English Names
- Diamond Values
- Category (small/medium/high)
- Color Information
- Difficulty Factors
```

#### `FishData.java`
- **المسؤولية**: تمثيل بيانات السمكة
- **البيانات**:
  - معرف السمكة
  - الموضع على الشاشة
  - السرعة والاتجاه
  - الثقة والنسبة

---

## تدفق البيانات

### دورة المعالجة الرئيسية

```
1. التقاط الشاشة
   ↓
2. تحويل إلى Bitmap
   ↓
3. كشف الأسماك
   ↓
4. تحليل الأسماك
   ↓
5. اختيار الأهداف
   ↓
6. رسم المؤشرات
   ↓
7. عرض على الشاشة
```

### معدل المعالجة

```
Frame Rate: 15 FPS
Frame Time: ~66ms

التفصيل:
- Capture:    ~20ms
- Detection:  ~30ms
- Analysis:   ~10ms
- Rendering:  ~6ms
```

---

## المكونات الرئيسية

### 1. MediaProjection API

```java
// في ScreenCaptureService
mediaProjection.createVirtualDisplay(
    "ScreenCapture",
    screenWidth, screenHeight, screenDensity,
    DisplayManager.VIRTUAL_DISPLAY_FLAG_PUBLIC,
    imageReader.getSurface(),
    null, handler
);
```

**الفوائد**:
- التقاط الشاشة بدون جذور
- دعم رسمي من Google
- أداء عالية

### 2. Color Detection

```java
// في FishDetector
private boolean isSignificantColor(int pixel) {
    int r = Color.red(pixel);
    int g = Color.green(pixel);
    int b = Color.blue(pixel);
    
    int brightness = (r + g + b) / 3;
    int saturation = max - min;
    
    return brightness > 30 && saturation > 20;
}
```

### 3. Flood Fill Algorithm

```java
// في FishDetector
private FishRegion floodFill(int[] pixels, boolean[] visited, 
                            int startIdx, int width, int height) {
    // تجميع البكسلات المتشابهة
    // حساب مركز المنطقة
    // إرجاع معلومات المنطقة
}
```

### 4. Tracking System

```java
// في FishAnalysisEngine
private void updateTrackingHistory(List<FishData> detectedFish) {
    for (FishData fish : detectedFish) {
        // تحديث السجل
        // حساب السرعة
        // حفظ التاريخ
    }
}
```

---

## إدارة الموارد

### الذاكرة

```
التوزيع التقريبي:
- Bitmap Frame:     ~10-20 MB
- Detection Data:   ~5-10 MB
- Tracking History: ~5 MB
- Overlay View:     ~2-5 MB
- Other:            ~10-20 MB
─────────────────────────────
Total:              ~50-100 MB
```

### CPU

```
استخدام CPU:
- Capture:    ~10%
- Detection:  ~40%
- Analysis:   ~15%
- Rendering:  ~10%
- Other:      ~25%
```

### البطارية

```
استهلاك البطارية:
- Foreground Service: معتدل
- Screen Capture:     عالي
- Processing:         معتدل
- Rendering:          منخفض
```

---

## نقاط التوسع

### إضافة ميزات جديدة

#### 1. إضافة نوع سمكة جديد

```java
// في FishDatabase.java
private void initializeFishDatabase() {
    addFish(13, "اسم عربي", "English Name", 50, "high", "color");
}
```

#### 2. تحسين الكشف

```java
// في FishDetector.java
// تعديل نطاقات الألوان
// إضافة معالجة متقدمة
// استخدام ML models
```

#### 3. تحسين التحليل

```java
// في FishAnalysisEngine.java
// تعديل الأوزان
// إضافة عوامل جديدة
// تحسين التنبؤ
```

---

## اختبار المكونات

### اختبار الكشف

```java
// في FishDetector
public void testDetection(Bitmap testFrame) {
    List<FishData> detected = detectFish(testFrame);
    assert detected.size() > 0;
    assert detected.get(0).confidence > 0.5f;
}
```

### اختبار التحليل

```java
// في FishAnalysisEngine
public void testAnalysis(List<FishData> fish) {
    AnalysisResult result = analyzeFish(fish);
    assert result.bestOverall != null;
    assert result.bestOverall.valueRatio > 0;
}
```

---

## الأداء والتحسينات

### التحسينات المستقبلية

1. **استخدام TensorFlow Lite**
   - كشف أفضل للأسماك
   - دعم أنماط معقدة
   - أداء أسرع

2. **معالجة متعددة الخيوط**
   - معالجة متوازية
   - تقليل الكمون
   - استخدام أفضل للموارد

3. **تحسينات الذاكرة**
   - استخدام Object Pooling
   - تقليل GC pauses
   - إدارة أفضل للموارد

4. **تحسينات الواجهة**
   - رسومات أفضل
   - تأثيرات بصرية
   - معلومات أكثر تفصيلاً

---

## الأمان والخصوصية

### الأذونات المطلوبة

```xml
<uses-permission android:name="android.permission.SYSTEM_ALERT_WINDOW" />
<uses-permission android:name="android.permission.FOREGROUND_SERVICE" />
<uses-permission android:name="android.permission.FOREGROUND_SERVICE_MEDIA_PROJECTION" />
```

### معالجة البيانات

- لا يتم تخزين بيانات الشاشة
- لا يتم إرسال البيانات للخادم
- معالجة محلية فقط

---

## الخلاصة

البنية المعمارية توفر:
- ✅ فصل واضح للمسؤوليات
- ✅ سهولة الصيانة والتطوير
- ✅ أداء عالية
- ✅ قابلية التوسع
- ✅ إدارة فعالة للموارد
