# 📲 دليل التثبيت والبناء - Fisher Likee Overlay

## المحتويات
1. [متطلبات النظام](#متطلبات-النظام)
2. [خطوات البناء](#خطوات-البناء)
3. [التثبيت على الجهاز](#التثبيت-على-الجهاز)
4. [استكشاف الأخطاء](#استكشاف-الأخطاء)

---

## متطلبات النظام

### للتطوير والبناء:

#### Windows:
- Android Studio 2023.1 أو أحدث
- Java Development Kit (JDK) 11+
- Android SDK API Level 34
- Gradle 8.1+
- 4 GB RAM على الأقل
- 10 GB مساحة قرص

#### macOS:
```bash
# استخدام Homebrew
brew install android-studio
brew install openjdk@11
```

#### Linux (Ubuntu/Debian):
```bash
sudo apt-get update
sudo apt-get install -y openjdk-11-jdk android-sdk
```

### للتثبيت على الجهاز:
- جهاز Android بإصدار 6.0 (API 24) أو أحدث
- USB cable (إذا كنت تستخدم ADB)
- تفعيل "Developer Options" على الجهاز

---

## خطوات البناء

### الطريقة الأولى: استخدام Android Studio (الأسهل)

#### 1. تثبيت Android Studio

- قم بتحميل [Android Studio](https://developer.android.com/studio) من الموقع الرسمي
- اتبع المثبت وأكمل التثبيت
- عند الانتهاء، سيطلب منك تثبيت Android SDK

#### 2. فتح المشروع

```
File → Open → اختر مجلد FisherOverlayApp
```

#### 3. انتظر مزامنة Gradle

- سيظهر شريط تقدم في الأسفل
- انتظر حتى ينتهي (قد يستغرق 5-10 دقائق في المرة الأولى)

#### 4. بناء APK

```
Build → Build Bundle(s) / APK(s) → Build APK(s)
```

#### 5. موقع الملف

سيظهر ملف APK في:
```
FisherOverlayApp/app/build/outputs/apk/debug/app-debug.apk
```

---

### الطريقة الثانية: استخدام سطر الأوامر

#### 1. تثبيت المتطلبات

**على Windows (PowerShell):**
```powershell
# تثبيت Java
choco install openjdk11

# تثبيت Android SDK
# من https://developer.android.com/studio
```

**على macOS:**
```bash
brew install openjdk@11
brew install android-sdk
```

**على Linux:**
```bash
sudo apt-get update
sudo apt-get install -y openjdk-11-jdk
# تثبيت Android SDK من موقع Google
```

#### 2. تعيين متغيرات البيئة

**على Windows (PowerShell):**
```powershell
$env:JAVA_HOME = "C:\Program Files\Java\openjdk-11"
$env:ANDROID_HOME = "C:\Users\YourUsername\AppData\Local\Android\Sdk"
```

**على macOS/Linux:**
```bash
export JAVA_HOME=/usr/libexec/java_home -v 11
export ANDROID_HOME=~/Library/Android/sdk  # macOS
# أو
export ANDROID_HOME=~/Android/Sdk  # Linux
```

#### 3. بناء APK

```bash
cd FisherOverlayApp

# بناء Debug APK
./gradlew assembleDebug

# أو بناء Release APK (يتطلب توقيع)
./gradlew assembleRelease
```

#### 4. موقع الملف

```
app/build/outputs/apk/debug/app-debug.apk
```

---

## التثبيت على الجهاز

### الطريقة الأولى: استخدام ADB (سطر الأوامر)

#### 1. تفعيل Developer Mode على الجهاز

- اذهب إلى Settings → About Phone
- اضغط على Build Number 7 مرات
- ستظهر رسالة "Developer mode enabled"

#### 2. تفعيل USB Debugging

- اذهب إلى Settings → Developer Options
- فعّل "USB Debugging"

#### 3. توصيل الجهاز

- وصّل الجهاز بالكمبيوتر عبر USB
- اختر "Allow" عندما يطلب الجهاز

#### 4. التثبيت

```bash
adb install app/build/outputs/apk/debug/app-debug.apk
```

#### 5. التحقق

```bash
adb shell pm list packages | grep fisher
```

### الطريقة الثانية: نقل يدوي

#### 1. نسخ الملف

- انسخ `app-debug.apk` إلى الجهاز عبر USB

#### 2. فتح مدير الملفات

- افتح مدير الملفات على الجهاز
- انتقل إلى مكان الملف

#### 3. التثبيت

- اضغط على الملف
- اختر "Install"
- اقبل الأذونات

### الطريقة الثالثة: استخدام Android Studio

#### 1. توصيل الجهاز

- وصّل الجهاز بالكمبيوتر

#### 2. اختيار الجهاز

```
Run → Select Device → اختر جهازك
```

#### 3. التشغيل

```
Run → Run 'app'
```

---

## منح الأذونات

عند تشغيل التطبيق لأول مرة:

### 1. أذونات SYSTEM_ALERT_WINDOW

- سيظهر طلب الأذونات
- اختر "Allow"

### 2. أذونات MediaProjection

- عند الضغط على "Start Overlay"
- سيظهر نافذة اختيار الشاشة
- اختر الشاشة الرئيسية

---

## استكشاف الأخطاء

### خطأ: "SDK location not found"

**الحل:**
```bash
# تأكد من وجود local.properties
cat local.properties

# يجب أن يحتوي على:
# sdk.dir=/path/to/android-sdk
```

### خطأ: "Could not find gradle"

**الحل:**
```bash
# تأكد من وجود gradlew
ls -la gradlew

# إذا لم يكن موجوداً
chmod +x gradlew
```

### خطأ: "Build failed"

**الحل:**
```bash
# نظف المشروع
./gradlew clean

# أعد المحاولة
./gradlew assembleDebug
```

### خطأ: "ADB not found"

**الحل:**
```bash
# على Windows
set PATH=%PATH%;C:\Users\YourUsername\AppData\Local\Android\Sdk\platform-tools

# على macOS/Linux
export PATH=$PATH:~/Library/Android/sdk/platform-tools
```

### خطأ: "No connected devices"

**الحل:**
```bash
# تحقق من الأجهزة المتصلة
adb devices

# إذا لم يظهر جهازك
# 1. أعد توصيل USB
# 2. فعّل USB Debugging على الجهاز
# 3. اختر "Allow" عند الطلب
```

### خطأ: "Permission denied"

**الحل:**
```bash
# على Linux/macOS
sudo chmod +x gradlew

# أو
./gradlew assembleDebug
```

---

## التحقق من التثبيت

### 1. التحقق من التطبيق

```bash
adb shell pm list packages | grep fisher
```

يجب أن تظهر:
```
package:com.fisher.overlay
```

### 2. تشغيل التطبيق

```bash
adb shell am start -n com.fisher.overlay/.MainActivity
```

### 3. عرض السجلات

```bash
adb logcat | grep FisherOverlay
```

---

## تحسين الأداء

### تقليل حجم APK

```bash
# بناء Release APK مع تقليل الحجم
./gradlew assembleRelease --minify
```

### تحسين الأداء

1. **قلل معدل الإطارات** في `ScreenCaptureService.java`:
```java
private static final int FRAME_RATE = 10; // من 15 إلى 10
```

2. **قلل دقة الالتقاط**:
```java
// في FishDetector.java
private static final int MIN_FISH_SIZE = 30; // من 20 إلى 30
```

---

## الخطوات التالية

بعد التثبيت الناجح:

1. **افتح لعبة Fisher Likee**
2. **افتح تطبيق Fisher Overlay**
3. **اضغط "Start Overlay"**
4. **منح الأذونات المطلوبة**
5. **شاهد المؤشرات على الأسماك!**

---

## الدعم

إذا واجهت مشاكل:

1. تحقق من [BUILD_GUIDE.md](BUILD_GUIDE.md)
2. راجع [README.md](README.md)
3. تحقق من السجلات في Logcat
4. فتح Issue على GitHub

---

**ملاحظة مهمة**: هذا التطبيق مخصص للاستخدام التعليمي والشخصي فقط.
